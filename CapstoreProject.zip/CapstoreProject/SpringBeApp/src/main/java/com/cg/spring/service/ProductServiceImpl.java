package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.Product;
import com.cg.spring.repo.IProductRepo;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo repo;
	
//	@Override
//	public List<Product> showAll() {
//		List<Product>list=new ArrayList<>();
//		repo.findAll().forEach(list::add);
//		return list;
//		
//		
//	}

	@Override
	public Optional<Product> getProductById(int product_id) {
		return repo.findById(product_id);
	}

}
