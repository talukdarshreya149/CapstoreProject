package com.cg.spring.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int product_id;
	private String product_name;
	private double product_price;
	private String product_modelname;
	private String product_category;
	private String product_type;
	private String product_description;
	private double discount;
	private long product_viewcount;
	private long product_soldcount;
	private long product_count;
	private String product_warranty;
	private String product_returnpolicy;
	private String product_imagename;
	@ManyToOne
	@JoinColumn(name="merchant_email")
	private Merchant merchant_email;
	
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getProduct_price() {
		return product_price;
	}
	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}
	public String getProduct_modelname() {
		return product_modelname;
	}
	public void setProduct_modelname(String product_modelname) {
		this.product_modelname = product_modelname;
	}
	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public String getProduct_description() {
		return product_description;
	}
	public void setProduct_description(String product_description) {
		this.product_description = product_description;
		
	}
	
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public long getProduct_count() {
		return product_count;
	}
	public void setProduct_count(long product_count) {
		this.product_count = product_count;
	}
	
	public long getProduct_viewcount() {
		return product_viewcount;
	}
	public void setProduct_viewcount(long product_viewcount) {
		this.product_viewcount = product_viewcount;
	}
	public long getProduct_soldcount() {
		return product_soldcount;
	}
	public void setProduct_soldcount(long product_soldout) {
		this.product_soldcount = product_soldout;
	}
	public String getProduct_warranty() {
		return product_warranty;
	}
	public void setProduct_warranty(String product_warranty) {
		this.product_warranty = product_warranty;
	}
	public String getProduct_returnpolicy() {
		return product_returnpolicy;
	}
	public void setProduct_returnpolicy(String product_returnpolicy) {
		this.product_returnpolicy = product_returnpolicy;
	}
	
	public String getProduct_imagename() {
		return product_imagename;
	}
	public void setProduct_imagename(String product_imagename) {
		this.product_imagename = product_imagename;
	}
	public Merchant getMerchant_email() {
		return merchant_email;
	}
	public void setMerchant_email(Merchant merchant_email) {
		this.merchant_email = merchant_email;
	}
	
	
	public Product(int product_id, String product_name, double product_price, String product_modelname,
			String product_category, String product_type, String product_description, double discount,
			long product_viewcount, long product_soldcount, long product_count, String product_warranty,
			String product_returnpolicy, String product_imagename, Merchant merchant_email) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_modelname = product_modelname;
		this.product_category = product_category;
		this.product_type = product_type;
		this.product_description = product_description;
		this.discount = discount;
		this.product_viewcount = product_viewcount;
		this.product_soldcount = product_soldcount;
		this.product_count = product_count;
		this.product_warranty = product_warranty;
		this.product_returnpolicy = product_returnpolicy;
		this.product_imagename = product_imagename;
		this.merchant_email = merchant_email;
	}
	public Product() {
		
	}
	
	
	
	
}
