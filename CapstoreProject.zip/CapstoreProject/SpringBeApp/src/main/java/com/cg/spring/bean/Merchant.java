package com.cg.spring.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "merchant")
public class Merchant {

	@Id
	private String merchant_email;
	private String name;
	private String mobile;
	
	public String getEmail() {
		return merchant_email;
	}
	public void setEmail(String email) {
		this.merchant_email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Merchant(String email, String name, String mobile) {
		super();
		this.merchant_email = email;
		this.name = name;
		this.mobile = mobile;
	}
	
	public Merchant() {
		
	}
}
