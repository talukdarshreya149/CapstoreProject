package com.cg.spring.service;


import java.util.Optional;

import com.cg.spring.bean.Product;

public interface IProductService {

	//public List<Product> showAll();

	public Optional<Product> getProductById(int product_id);
}
